export default function VisitProfile() {
    return (
        <div>Hello</div>
    )
}